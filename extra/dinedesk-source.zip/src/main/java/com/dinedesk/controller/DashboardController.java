
package com.dinedesk.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.stage.Stage;

import java.io.IOException;

public class DashboardController {

    @FXML
    private void openDashboard(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/dashboard.fxml");
    }

    @FXML
    private void openNewOrder(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/NewOrder.fxml");
    }

    @FXML
    private void openOrders(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/orders.fxml");
    }

    @FXML
    private void openMenu(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/menu.fxml");
    }

    @FXML
    private void openCustomers(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/customers.fxml");
    }

    @FXML
    private void openReports(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/reports.fxml");
    }

    @FXML
    private void openSettings(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/settings.fxml");
    }

    @FXML
    private void openBackup(javafx.event.ActionEvent event) {
        navigate(event, "/com/dinedesk/view/backup.fxml");
    }

    private void navigate(javafx.event.ActionEvent event, String path) {
        try {
            Parent page = FXMLLoader.load(
                    getClass().getResource(path)
            );

            Node source = (Node) event.getSource();
            Stage stage = (Stage) source.getScene().getWindow();

            stage.getScene().setRoot(page);

        } catch (IOException | NullPointerException e) {
            e.printStackTrace();
        }
    }
}
