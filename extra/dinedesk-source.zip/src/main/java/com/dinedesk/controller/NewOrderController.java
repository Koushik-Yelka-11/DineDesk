
package com.dinedesk.controller;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.TilePane;

public class NewOrderController {

    @FXML private ComboBox<String> orderTypeCombo;
    @FXML private TextField customerField;
    @FXML private TextArea orderNoteArea;
    @FXML private TextField searchField;
    @FXML private ComboBox<String> categoryCombo;
    @FXML private Label itemCountLabel;
    @FXML private TilePane menuTilePane;
    @FXML private ListView<String> cartListView;
    @FXML private Label subtotalLabel;
    @FXML private Label discountLabel;
    @FXML private Label taxLabel;
    @FXML private Label grandTotalLabel;

    @FXML
    private void initialize() {
        orderTypeCombo.getItems().setAll("Dine In", "Takeaway");
        orderTypeCombo.setValue("Dine In");

        customerField.setText("Walk-in customer");

        subtotalLabel.setText("₹0.00");
        discountLabel.setText("₹0.00");
        taxLabel.setText("₹0.00");
        grandTotalLabel.setText("₹0.00");

        itemCountLabel.setText("Menu items");
    }

    @FXML private void openDashboard() {}
    @FXML private void openNewOrder() {}
    @FXML private void openOrders() {}
    @FXML private void openMenu() {}
    @FXML private void openCustomers() {}
    @FXML private void openReports() {}
    @FXML private void openSettings() {}
    @FXML private void openBackup() {}
    @FXML private void clearOrder() {}
    @FXML private void searchMenuItems() {}
    @FXML private void filterByCategory() {}
    @FXML private void removeSelectedItem() {}
    @FXML private void saveOrder() {}
}
